# Application de chat en JAVA RMI
